﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ПрофессиональныйТехническийУниверситет
{
    /// <summary>
    /// Логика взаимодействия для Authorize.xaml
    /// </summary>
    public partial class Authorize : Window
    {
        Entities BD_Entities = new Entities();
        public Authorize()
        {
            InitializeComponent();
        }

        private void AuthorizeButton_Click(object sender, RoutedEventArgs e)
        {
            if ((Login.Text != "") && (Password.Text != ""))
            {
                string role = "";
                string login="";
                bool userExists = false;
                foreach (var user in BD_Entities.Users)
                {
                    if ((Login.Text == user.Логин) && (Password.Text == user.Пароль))
                    {
                        userExists = true;
                        role = user.Роль;
                        login = user.Логин;
                        break;
                    }
                }
                if (userExists == false) MessageBox.Show("Вы ввели неверный логин или пароль. Пожалуйста, проверьте еще раз данные");
                else
                {
                    switch (role)
                    {
                        case "Студент":
                            StudentMainWindow stud = new StudentMainWindow(login);
                            stud.Show();
                            this.Close();
                            break;
                        case "Преподаватель":
                            break;
                        case "Администратор":
                            break;
                        case "Дирекция":
                            break;
                        default:
                            break;
                    }
                }
            }
            else MessageBox.Show("Пожалуйста, заполните все поля");
        }
    }
}
